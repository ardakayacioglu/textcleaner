to_lowercase <- function(text) {
  tolower(text)
}
