stopifnot(remove_specials("Hello, World!") == "Hello World")
stopifnot(remove_specials("123#456") == "123456")
