stopifnot(to_lowercase("ABC") == "abc")
stopifnot(to_lowercase("HeLLo") == "hello")
